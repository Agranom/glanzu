var tipuedrop = {"pages": [
     {	"title": "Блабландия", 
     	"url": "https://www.google.com.ua/"
     },
     {	"title": "Малые Блаблавичи", 
     	"url": "#"
     },
     {	"title": "Москва", 
     	"url": "https://www.yandex.ru/"
     },
     {	"title": "Киев", 
     	"url": "https://www.yandex.ua/"
     }
]};